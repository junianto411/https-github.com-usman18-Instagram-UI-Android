# Instagram-UI-Android ❤️
An Instagram UI recreation in Android with slight customizations like curved bottom nav and a new profile look.

Go ahead and play around with the UI!

[Inspiration](https://www.instagram.com/p/BvTNK7IhG-k/?utm_source=ig_web_options_share_sheet)


## ScreenShots

<img height=550 width=275 src="https://github.com/usman18/Instagram-UI-Android/blob/master/Screenshots/InstaUI3.JPG" hspace=120
/>
<img height=550 width=275 src="https://github.com/usman18/Instagram-UI-Android/blob/master/Screenshots/InstaUI4.JPG"
/> 


## Contributions
Contributions are always welcome. Please fork this repository and contribute using pull requests. The pull requests will be thoroughly assessed and if found significant will be accepted.

## Lets become friends
- [Medium](https://medium.com/@usman18)
- [Instagram](https://www.instagram.com/usman__khan18/)
- [Twitter](https://twitter.com/khan_usman_18)
- [LinkedIn](https://www.linkedin.com/in/usman-khan-7b04b1138)
- [Github](https://github.com/usman18)

My email : uk32971@gmail.com
